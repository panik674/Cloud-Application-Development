var socket = null;

//Prepare game
var app = new Vue({
    el: '#game',
    data: {
        connected: false,
        me: {},
        state: {},
        loggedIn: false,
        loginUsername: '',
        loginPassword: '',
        password: '',
        registerUsername: '',
        registerPassword: '',
        prompt: '',
        firstPrompt: {},
        secondPrompt: {},
        promptSubmitted: false,
        firstAnswer: '',
        secondAnswer: '',
        //firstAnswerSubmitted: false,
        //secondAnswerSubmitted: false,
        answerSubmitted: false,
        bothSubmitted: false,
        submissionNumber: 0,
        voteSubmitted: false,
        sortedList:[],
        newPrompts:[],
        promptAndAnswers:[],
        currentPrompts:[],
        previousPandA:{},
        skipDisabled: false,
        loginDisabled: false,
        registerDisabled: false,
        roundPrompts: [],

    },
    mounted: function() {
        connect(); 
    },
    methods: {
        //handleChat(message) {
            //if(this.messages.length + 1 > 10) {
                //this.messages.pop();
            //}
            //this.messages.unshift(message);
        //},
        login() {
            if(!this.loginDisabled){
            //if(this.loginUsername != '' && this.loginPassword !=''){
            socket.emit('login',{username: this.loginUsername, password: this.loginPassword});
            this.password = this.loginPassword;
            this.loginUsername = '';
            this.loginPassword = '';
            this.loginDisabled = true;
            this.registerDisabled = true;
            }
            //}
            //else{
                //alert("Username or password incorrect");
            //}
        },
        register() {
            //if(this.registerUsername != '' && this.registerPassword !=''){
            if(!this.registerDisabled){
            socket.emit('register',{username: this.registerUsername, password: this.registerPassword});
            this.registerUsername = '';
            this.registerPassword = '';
            this.registerDisabled = true;
            this.loginDisabled = true;
            }

            //}
        },
        advanceToPrompts(){
            const audio = new Audio();
            audio.src = "/static/advance.mp3";
            audio.play();
            socket.emit('advanceToPrompts',"");
            
            
        },

        createPrompt(skip){
            if(skip){
                if(!this.skipDisabled){
                const audio = new Audio();
                audio.src = "/static/skip.mp3";
                audio.play();       
                this.promptSubmitted = true;
                socket.emit('createPrompt','skip');
                }
            }
            else{
                const audio = new Audio();
                audio.src = "/static/submit.mp3";
                audio.play();
                this.skipDisabled = true; 
                socket.emit('createPrompt',{text: this.prompt, username: this.me.username, password: this.password});
            //this.newPrompts.push(this.prompt);
            //if(this.me.number != 1){
            
            //document.getElementById('promptInput').remove();
            //}
            //else{
                //document.getElementById('promptField').remove();
            //}
            this.prompt = '';
            }
            //this.promptSubmitted=true;
            //document.getElementById('waitingMessage').remove();
        },
        
            
        
        answers(){
            //this.firstPrompt = this.state.prompts[0].text
            //alert(this.state.prompts[0].text);
            //this.secondPrompt = this.state.prompts[1].text
            const audio = new Audio();
            audio.src = "/static/advance.mp3";
            audio.play();
            socket.emit('startAnswers', this.prompt)
            this.promptAndAnswers = [];
            
            //newPrompts.push(this.prompt);
            
        },
        submitAnswers(first){
            //if(this.state.players.length % 2 == 0){
            const audio = new Audio();
            audio.src = "/static/submit.mp3";
            if(first){
                
                if(this.firstAnswer.length > 0 &&  this.firstAnswer.length < 100){
                audio.play();
                socket.emit("submitAnswers", {player: this.me, prompt:this.firstPrompt, answer:this.firstAnswer})
                document.getElementById('FirstAnswer').remove();
                this.submissionNumber += 1;
                //this.previousPandA.push({prompt:this.firstPrompt, answer: this.firstAnswer});
                socket.emit("promptsAndAnswers",{prompt:this.firstPrompt, answer: this.firstAnswer});
                }
                else{
                    alert("Answers must be >0 and <100");
                }
                
            }
            else{
                
                if(this.secondAnswer.length > 0 &&  this.secondAnswer.length < 100){
                audio.play();
                socket.emit("submitAnswers", {player: this.me, prompt: this.secondPrompt, answer:this.secondAnswer})
                document.getElementById('SecondAnswer').remove();
                this.submissionNumber += 1;
                //this.previousPandA.push({prompt:this.firstPrompt, answer: this.firstAnswer});
                socket.emit("promptsAndAnswers",{prompt:this.secondPrompt, answer: this.secondAnswer});
                }
                else{
                    alert("Answers must be >0 and <100");
                }
            }
            //}
            //else{
                //socket.emit("submitAnswers", {Player: this.me, firstPrompt:{text: this.firstPrompt, answer: this.firstAnswer}, secondPrompt:{text: this.secondPrompt, answer: this.secondAnswer}})
            //}
            
            if(this.submissionNumber == this.state.prompts.length){
                this.bothSubmitted = true;
            }
            
            this.answerSubmitted = true;
             
            
        },
        endAnswers(){
            //document.getElementById('answers').remove();
            //if(this.me.number != 1){
            //document.getElementById('waitingMessage').remove();
            //}
            //document.getElementById('advance').remove();

            socket.emit('endAnswers','');
            const audio = new Audio();
            audio.src = "/static/advance.mp3";
            audio.play();
            //alert(state.state);
            
        },
        sendVotes(player){
            const audio = new Audio();
            audio.src = "/static/vote.mp3";
            audio.play();
            if(player == 1){
                this.state.currentPrompt.player1.votes = this.state.currentPrompt.player1.votes + 1;
                socket.emit('sendVotes', {state:this.state.currentPrompt, player: 1});
                //document.getElementById('answerVote').remove();
            }
            else{
                this.state.currentPrompt.player2.votes = this.state.currentPrompt.player2.votes + 1;
                socket.emit('sendVotes', {state:this.state.currentPrompt, player: 2});
                //document.getElementById('answerVote').remove();
            }
            this.voteSubmitted = true;
            
        },
        startScores(){
            const audio = new Audio();
            audio.src = "/static/advance.mp3";
            audio.play();
            socket.emit('startScores','');

            
            
        },
        nextVote(){
            
            const audio = new Audio();
            audio.src = "/static/advance.mp3";
            audio.play();
            socket.emit('nextVote','');
        },
        roundScores(){
            
            const audio = new Audio();
            audio.src = "/static/advance.mp3";
            audio.play();
            socket.emit('startRoundScores','')
        },
        nextRound(){
            
            const audio = new Audio();
            audio.src = "/static/advance.mp3";
            audio.play();
            socket.emit('nextRound', '')
        },
        gameOver(){
            
            const audio = new Audio();
            audio.src = "/static/advance.mp3";
            audio.play();
            socket.emit('gameOver','');
        }

    }
});

function connect() {
    //Prepare web socket
    socket = io();

    //Connect
    socket.on('connect', function() {
        //Set connected state to true
        app.connected = true;
    });

    //Handle connection error
    socket.on('connect_error', function(message) {
        alert('Unable to connect: ' + message);
    });

    //Handle disconnection
    socket.on('disconnect', function() {
        alert('Disconnected');
        app.connected = false;
        
    });

    socket.on('loginFailed',function(message){
        alert(message.msg);
        app.loginDisabled = false;
        app.registerDisabled = false;
    });

    socket.on('promptFailed',function(message){
        alert(message.msg);
        app.skipDisabled = false;
    });

    socket.on('promptSuccessful',function(message){
        app.promptSubmitted=true;
        app.skipDisabled = false;

    });

    socket.on('registerFailed',function(message){
        alert(message.msg);
        app.registerDisabled = false;
        app.loginDisabled = false;
    });

    socket.on('registerSuccess',function(message){
        alert("Registration Successful");
        app.loginDisabled = false;
    });

    socket.on('loginPlayerUpdate', function(message){
        //alert(message);
        app.loggedIn = true;
        app.state = message;
        if(app.me = {}){
        app.me = app.state.players[app.state.players.length - 1];
        }
        document.getElementById('login').remove();
        //app.loggedIn = true;
        //if(app.me.loggedIn == true){
            //Login.getElementById('login').remove();
        //}
    });

    socket.on('loginAudienceUpdate', function(message){
        //alert(message);
        app.loggedIn = true;
        app.state = message;
        if(app.me = {}){
        app.me = app.state.audience[app.state.audience.length - 1];
        }
        document.getElementById('login').remove();
        //app.loggedIn = true;
        //if(app.me.loggedIn == true){
            //Login.getElementById('login').remove();
        //}
    });




    socket.on('stateUpdate', function(message){
        app.state = message;
        app.sortedList = (app.state.players).sort((prev,next) => next.score - prev.score)
        
        if(app.state.prompts != {}){
            app.firstPrompt = app.state.prompts[0];
        
        if(app.state.prompts.length > 1){
            app.secondPrompt = app.state.prompts[1];
            
        }
    }
    
            //else{
                //app.firstPrompt = app.state.prompts[0];
                //if(app.state.prompts.length > 1){
                    //app.secondPrompt = app.state.prompts[1];
                //}
                
            //}
        });

    socket.on('voteUpdate', function(message){
        app.state = message;
        app.sortedList = (app.state.players).sort((prev,next) => next.score - prev.score)
        
    });

    socket.on('disconnectUpdate', function(message){
        app.state = message;
        for(let i = 0; i < app.state.players.length; i++){
            if(app.state.players[i].username == app.me.username){
                app.me = app.state.players[i];
                app.me.number = i + 1;
                //app.state.players[i].number = i;
            }
        }
        
        
        //socket.emit("scoreUpdate",app.state);
        
    });

    socket.on('voteSendUpdate', function(message){
        app.state = message;
        app.sortedList = (app.state.players).sort((prev,next) => next.score - prev.score)
        for(let i = 0; i < app.state.players.length; i++){
            if(app.state.players[i].username == app.state.currentPrompt.player1.username){
                app.state.currentPrompt.player1.score = app.state.players[i].score;
            }
            if(app.state.players[i].username == app.state.currentPrompt.player2.username){
                app.state.currentPrompt.player2.score = app.state.players[i].score;
            }
        }
        for(let i = 0; i < app.state.players.length; i++){
            if(app.me.username == app.state.players[i].username){
                app.me.score = app.state.players[i].score;
            }
        }
        socket.emit("scoreUpdate",app.state);
        
    });



    socket.on('nextVoteUpdate', function(message){
        app.voteSubmitted = false;
        app.state = message;
        
        
    });

    socket.on('uncheck', function(message){
        app.firstPrompt = {};
        app.secondPrompt = {};
        app.firstAnswer = '';
        app.secondAnswer = '';
        app.answerSubmitted = false;
        app.bothSubmitted = false;
        app.promptSubmitted = 0;
        app.submissionNumber = 0;
        app.voteSubmitted = false;
        app.promptAndAnswers = [];
    });

    socket.on('state', function(message){
        app.state = message;
        app.sortedList = (app.state.players).sort((prev,next) => next.score - prev.score)
        app.promptAndAnswers = [];
    });

    socket.on('newPrompts', function(message){
        app.newPrompts = message;
    });

    socket.on('prompts', function(message){
        app.currentPrompts = message;
    });
    socket.on('answers', function(message){
        app.promptAndAnswers = message;
        //console.log(promptAndAnswers);
        //var answers = [];
        //if(app.state.players.length % 2 != 0){
            //for(let i = 0; i < app.currentPrompts.length; i++){
                //if(app.state.[i] == ){
                    //answers.push(firstAnswer)
                    //app.promptAndAnswers.push({prompt: firstPrompt.text, answer:answers})
                //}
                //if(app.currentPrompt[i] == secondPrompt.text){
                    //answers.push(firstAnswer)
                    //app.promptAndAnswers.push({prompt: firstPrompt.text, answer:answers})
                //}
            //}
        //}
        //else{
            //for(let i = 0; i < app.currentPrompts.length; i++){
                //if(app.currentPrompt[i] == firstPrompt){
                    //answers.push(firstAnswer)
                    //app.promptAndAnswers.push({prompt: firstPrompt, answer:answers})
                //}
            //}
        //}
        //socket.send('promptsAndAnswers',app.promptAndAnswers);
    });
    socket.on('inGame', function(message){
        alert("A game is already in session");
    });

    socket.on('exists', function(message){
        alert("This user is already logged in");
    });
    //socket.on('stateSort', function(message){
        //app.state = message;
        
    //});
    


    

    //socket.on('voteSendUpdate', function(message){
        //app.state.currentPrompt = message;
    //});

    
            //if(app.firstPrompt != ''){
                //app.secondPrompt = app.state.prompts
            //}
            //else{
                //app.secondPrompt = app.state.prompts
            //}
        //}
    

    //socket.on('promptUpdate', function(message){
        //app.state = message;
    //});



    //Handle incoming chat message
    //socket.on('', function(message) {
        //app.handleChat(message);
    //});



}
