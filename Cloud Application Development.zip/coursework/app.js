'use strict';

const { ConflictResponse } = require('@azure/cosmos');
const { json } = require('express');
//Set up express
const express = require('express');
const { cp } = require('fs');
const app = express();

//Setup socket.io
const server = require('http').Server(app);
const io = require('socket.io')(server);


let players = [];
let playersToSockets = new Map();
let socketsToPlayers = new Map();
let audience = [];
let audienceToSockets = new Map();
let socketsToAudience = new Map();
let prompts = [];
let answers = [];
let currentPrompt = null;
let votes = 0;
let roundScores = [];
let totalScores = [];
let apiPrompts = [];
let newPrompts = [];
let combosToPrompts = new Map();
let promptsToCombos = new Map();
let promptNumber;
let socketsToPrompts = new Map();
let socketToPrompts = new Map();
let playerCombos = [];
let promptsSubmitted = 0;
let answersSubmitted = 0;
let emptyPrompts = 0;
let roundNumber = 1;
let playerNumberAdjust = new Map();
let audienceNumberAdjust = new Map();
let displaySockets = [];
let allPrompts = [];
let promptsAndAnswers = [];




var state = {state: 0, players: players, audience: audience, prompts:prompts, answers:answers, votes:votes, currentPrompt:currentPrompt, roundscores:roundScores, totalscores:totalScores, round: roundNumber};

//Setup static page handling
app.set('view engine', 'ejs');
app.use('/static', express.static('public'));

//Handle client interface on /
app.get('/', (req, res) => {
  res.render('client');
});
//Handle display interface on /display
app.get('/display', (req, res) => {
  res.render('display');
});

 

//Start the server
function startServer() {
    const PORT = process.env.PORT || 8080;
    server.listen(PORT, () => {
        console.log(`Server listening on port ${PORT}`);
    });
}


//Chat message
function handleLogin(message,socket) {
  //console.log(players);
  //console.log(state.players);
  //console.log(playersToSockets);
  apiFunction(message,"/api/player/login").then((res) => {
      var usernameExists = false;
      for(let i = 0; i < players.length; i++){
        if(players[i].username ==  message.username){
          usernameExists = true;
          socket.emit("exists",'');
          break;
        }
      }
      if(res.result == true && players.length < 8 && usernameExists == false && state.state <= 1){
        if(players.length == 0){
          state.state = 1
        }
        
        players.push({username: message.username, number: players.length + 1, role: "player", score: 0});
        //console.player.length
        //console.log(playersToSockets);
        
        playersToSockets.set(players.length, socket);
        //console.log(playersToSockets);
        socketsToPlayers.set(socket,players.length);
        players = state.players;
        //console.log(players);
        //console.log(state.players);
        //console.log(playersToSockets);
        //console.log(state);
        //console.log("hello");
        
        playersToSockets.get(playersToSockets.size).emit('loginPlayerUpdate', state);
        for(let i = 0; i < displaySockets.length; i++){
          displaySockets[i].emit('state',state);
        }

    
      }
      if((res.result == true && players.length > 8 && usernameExists == false) || state.state > 1){
        
        audience.push({username: message.username, number: players.length + audience.length + 1, role: "audience"});
        audienceToSockets.set(players.length + audience.length + 1, socket);
        socketsToAudience.set(socket, players.length + audience.length + 1)
        audienceToSockets.get(players.length + audience.length + 1).emit('loginAudienceUpdate', state);
        for(let i = 0; i < displaySockets.length; i++){
          displaySockets[i].emit('state',state);
        }
      }
      if(res.result == false){
        socket.emit("loginFailed",res);
      }
      
      
    });
    }

  function handleRegister(message,socket) { 
    apiFunction(message,"/api/player/register").then((res) => {
      if(res.result == false){
        socket.emit("registerFailed",res);
      }
      else{
        socket.emit("registerSuccess",'');
      }
      });
    }

    function handleCreatePrompt(message,socket) {
      if(message == 'skip'){
        promptsSubmitted += 1;
      }
      else{
      apiFunction(message,"/api/prompt/create").then((res) => {
        
        if(res.result == false){
          socket.emit("promptFailed",res);
        }
        else{
        socket.emit("promptSuccessful",'');
        if(message.text != ''){
        newPrompts.push(message);
        for(let i = 0; i < displaySockets.length; i++){
          displaySockets[i].emit('newPrompts',newPrompts);
        }
        }
        //console.log(newPrompts);
        state.prompts = prompts;
        for(let [key, value] of playersToSockets){
          value.emit('stateUpdate', state);
        }
        for(let [key, value] of audienceToSockets){
          value.emit('stateUpdate', state);
        }
        for(let i = 0; i < displaySockets.length; i++){
          displaySockets[i].emit('state',state);
        }
        //console.log(apiPrompts.filter(n => !newPrompts.includes(n)))
        promptsSubmitted += 1;
      }
        });
      }
      
        
        
      
      
    }

  function handleAdvanceToPrompts(){
    state.state = 2;
    if(players.length % 2 == 0){
      promptNumber = players.length / 2;
    }
    else{
      promptNumber = players.length;
    }
    apiFunction({"prompts": 9007199254740991},"/api/prompts/get").then((res) => {
      for(let i = 0; i < res.length; i++){
        apiPrompts.push(res[i]);
        //console.log(apiPrompts);
      }
      for(let [key, value] of playersToSockets){
        value.emit('stateUpdate', state);
      }
      for(let [key, value] of audienceToSockets){
        value.emit('stateUpdate', state);
      }
      for(let i = 0; i < displaySockets.length; i++){
        displaySockets[i].emit('state',state);
      }
    });

    

    

    
    
    
  }

  function handleStartAnswers(){
    allPrompts = [];
    //console.log(state);
    //console.log(newPrompts);
    //console.log("api");
    //console.log(apiPrompts);
    var oddComboPlayers;
    var evenComboPlayers;
    var odd = true;
    //console.log(promptNumber);
    if((players.length % 2) == 0 ){
      getPromptsEven();
      evenComboPlayers = [];
      odd = false;
      //if((promptNumber / 2) % 2 == 0){
        //getPromptsEven();
        //evenComboPlayers = [];
        //odd = false;
      //}
      //else{
        //getPromptsOdd();
        //oddComboPlayers = players.concat(players);
      //}
    }
    if((players.length % 2) != 0  ){
      getPromptsOdd();
      oddComboPlayers = players.concat(players);
    }
    
    //console.log("---");
    //console.log(oddComboPlayers);
    //console.log("---");
    state.state = 3;
    state.prompts = prompts;
    //console.log(players);
    if(odd){
    //console.log(oddComboPlayers);
    playerCombos = shuffle(sliceIntoChunks(oddComboPlayers,2));
    }
    else{
      //console.log("even");
      for (let i=0; i<players.length; i+=2) {
        evenComboPlayers.push([players[i], players[i+1]])
      }
      playerCombos = shuffle(evenComboPlayers);
    }
    //console.log(prompts);
    //console.log(sliceIntoChunks(comboPlayers,2))
    //for (let i = 0; i < players.length; i += chunkSize) {
      //const chunk = players.slice(i, i + chunkSize);
      //console.log(chunk);
    //}
    for(let i = 0; i < prompts.length; i++){
      combosToPrompts.set(playerCombos[i], prompts[i]);
    }

    //for(let i = 0; i < combosToPrompts.length; i++){
      //socketsToPrompts.set([playersToSockets.get(),playersToSockets.get(i+2)])

    //This part for prompt sockets
    var comboToPromptsValues = Array.from(combosToPrompts.keys());
    for(let i = 0; i<comboToPromptsValues.length; i++){
      socketsToPrompts.set([playersToSockets.get(comboToPromptsValues[i][0].number),playersToSockets.get(comboToPromptsValues[i][1].number)], prompts[i]);
    }
    
    //console.log(socketsToPrompts);

    var socketsDups = [];
    for( let [key, value] of socketsToPrompts ){
      socketsDups.push(key[0]);
      socketsDups.push(key[1]);
    }

    //console.log(socketsDups);

    var sockets = Array.from(new Set(socketsDups));

    //console.log("------");
    //console.log(sockets);
    //console.log("------");

    //console.log(socketsToPrompts);

    for( let i = 0; i < sockets.length; i ++){
      var promptList = [];
      for(let [key, value] of socketsToPrompts){
        //console.log("-----");
        //console.log(key[0]);
        //console.log("-----");
        //var promptList = [];
        if(sockets[i] == key[0] || sockets[i] == key[1]){
          promptList.push(value);
          socketToPrompts.set(sockets[i],promptList);
        }
        //console.log("-----");
        //console.log(sockets[i]); 
        //console.log(key[0]);
        //console.log(key[1]);
        //console.log("-----");

    }
  }
    
    
    for(let [key, value] of combosToPrompts){
      allPrompts.push(value.text);
      }

    //console.log(allPrompts);
    //

    
    for(let [key, value] of socketToPrompts){
        state.prompts = value;
        //console.log(typeof state.prompts[1]);
        //console.log(state.prompts.length);
        key.emit('stateUpdate', state); 
    }
    
    //console.log(state);
    for(let i = 0; i < displaySockets.length; i++){
      displaySockets[i].emit('state', state);
    }
    for(let i = 0; i < displaySockets.length; i++){
      displaySockets[i].emit('prompts', allPrompts);
    }

  }

  function handleSubmitAnswers(message){
    answersSubmitted += 1;
    state.answers.push(message);
    for(let i = 0; i < displaySockets.length; i++){
      displaySockets[i].emit('answers', '');
    }
    

  }

  function handleEndAnswers(){
    state.state = 4;
    //console.log("combosToPrompts");
    //console.log(combosToPrompts);
    //console.log("Answers");
    //console.log(answers);
    for(let i = 0; i < state.answers.length; i++){
      for(let [key,value] of combosToPrompts){
        if(state.answers[i].player.username == key[0].username && state.answers[i].prompt.id == value.id){
          try{
            promptsToCombos.set(value, [{username:key[0].username, number:key[0].number, role:key[0].role, score:key[0].score, answer:state.answers[i].answer},promptsToCombos.get(value)[1]]);
          }
          catch(err){
            promptsToCombos.set(value, [{username:key[0].username, number:key[0].number, role:key[0].role, score:key[0].score, answer:state.answers[i].answer},key[1]]);
          }
        }
        if(state.answers[i].player.username == key[1].username && state.answers[i].prompt.id == value.id ){
          try{
            promptsToCombos.set(value ,[promptsToCombos.get(value)[0],{username:key[1].username, number:key[1].number, role:key[1].role, score:key[1].score, answer:state.answers[i].answer}]);
          }
          catch(err){
            promptsToCombos.set(value ,[key[0],{username:key[1].username, number:key[1].number, role:key[1].role, score:key[1].score, answer:state.answers[i].answer}]);
          }
      }
    }
  }
  //console.log("promptsToCombos");
  //console.log(promptsToCombos);
  var votingAnswers = [];
  //console.log(promptsToCombos);
    for(let [key, value] of promptsToCombos){
      votingAnswers.push({promptId: key.id, promptText: key.text, player1:{username:value[0].username, answer:value[0].answer, votes:0, score:0},player2:{username:value[1].username, answer:value[1].answer, votes:0, score:0}})
    }
    state.answers = votingAnswers;
    state.currentPrompt = votingAnswers[0];
    votingAnswers.shift();
    for(let [key, value] of playersToSockets){
      value.emit('voteUpdate', state);
    }
    for(let [key, value] of audienceToSockets){
      value.emit('voteUpdate', state);
    }
    for(let i = 0; i < displaySockets.length; i++){
      displaySockets[i].emit('state',state);
    }
    

    

  }

  function handleSendVotes(message){
    //console.log(message);
    state.currentPrompt.player1.votes = message.state.player1.votes;
    state.currentPrompt.player2.votes = message.state.player2.votes;
    

    for(let i = 0; i < state.players.length; i++){
      //console.log(state.players[i]);
      //console.log(state.currentPrompt.player1);
      //console.log(state.currentPrompt.player2);
      //console.log("-----");
      if(state.players[i].username == state.currentPrompt.player1.username && message.player == 1){
        if(state.round != 4){
        state.players[i].score += roundNumber * 100;
        }
        else{
          state.players[i].score -= roundNumber * 100;
        }
      }
      if(state.players[i].username == state.currentPrompt.player2.username && message.player == 2){
        if(state.round != 4){
          state.players[i].score += roundNumber * 100;
          }
          else{
            state.players[i].score -= roundNumber * 100;
          }
      }
    }

    //console.log(state);
    for(let [key, value] of playersToSockets){
      value.emit('voteSendUpdate', state);
    }
    for(let [key, value] of audienceToSockets){
      value.emit('voteSendUpdate', state);
    }
    for(let i = 0; i < displaySockets.length; i++){
      displaySockets[i].emit('state',state);
    }
  }

  function handleEndVotes(){
    state.state = 5;
    for(let [key, value] of playersToSockets){
      value.emit('voteUpdate', state);
    }
    for(let [key, value] of audienceToSockets){
      value.emit('voteUpdate', state);
    }
    for(let i = 0; i < displaySockets.length; i++){
      displaySockets[i].emit('state',state);
    }
  }

  function handleNextVote(){
    state.state = 4;
    state.currentPrompt = state.answers[0];
    state.answers.shift();
    for(let [key, value] of playersToSockets){
      value.emit('nextVoteUpdate', state);
    }
    for(let [key, value] of audienceToSockets){
      value.emit('nextVoteUpdate', state);
    }
    for(let i = 0; i < displaySockets.length; i++){
      displaySockets[i].emit('state',state);
    }
  }

  function handleStartRoundScores(){
    state.state = 6;
    for(let [key, value] of playersToSockets){
      value.emit('voteUpdate', state);
    }
    for(let [key, value] of audienceToSockets){
      value.emit('voteUpdate', state);
    }
    for(let i = 0; i < displaySockets.length; i++){
      displaySockets[i].emit('state',state);
    }
  }

  function handleNextRound(){
    roundNumber += 1;
    state.round = roundNumber;
    //console.log(newPrompts);
    for(let [key, value] of playersToSockets){
      value.emit('uncheck', '');
    }
    for(let [key, value] of audienceToSockets){
      value.emit('uncheck', '');
    }
    state.state = 2;
    newPrompts = [];
    prompts = [];
    state.prompts = [];
    answers = [];
    state.answers = [];
    votes = 0;
    state.votes = 0;
    currentPrompt = null;
    state.currentPrompt = null;
    combosToPrompts = new Map();
    promptsToCombos = new Map();
    socketsToPrompts = new Map();
    socketToPrompts = new Map();
    playerCombos = [];
    promptsSubmitted = 0;
    answersSubmitted = 0;
    emptyPrompts = 0
    //console.log(state);

    handleAdvanceToPrompts();
    

    //handleStartAnswers();
    for(let [key, value] of playersToSockets){
      value.emit('voteUpdate', state);
    }
    for(let [key, value] of audienceToSockets){
      value.emit('voteUpdate', state);
    }
    for(let i = 0; i < displaySockets.length; i++){
      displaySockets[i].emit('state',state);
    }
  }

  function handleGameOver(){
    state.state = 7;
    for(let [key, value] of playersToSockets){
      value.emit('voteUpdate', state);
    }
    for(let [key, value] of audienceToSockets){
      value.emit('voteUpdate', state);
    }
    for(let i = 0; i < displaySockets.length; i++){
      displaySockets[i].emit('state',state);
    }
  }

  function handleDisconnect(socket){
    //console.log(playersToSockets);
    playersToSockets.delete(socketsToPlayers.get(socket));
    audienceToSockets.delete(socketsToAudience.get(socket));;
    socketsToPlayers.delete(socket);
    socketsToAudience.delete(socket);
    //console.log(playersToSockets);
    //console.log(socketsToPlayers);
    players = [];
    audience = [];
    for(let [key,value] of playersToSockets){
      for(let i = 0; i < state.players.length; i++){
        if(state.players[i].number == key){
          players.push(state.players[i])
        }
      }
    }
    for(let [key,value] of audienceToSockets){
      for(let i = 0; i < state.audience.length; i++){
        if(state.audience[i].number == key){
          audience.push(state.audience[i])
        }
      }
    }
    for(let i = 0; i < players.length; i++){
      players[i].score = 0;
    }
    //players = Array.from(playersToSockets.keys());
    state.players = players;
    //audience = Array.from(audienceToSockets.keys());
    state.audience = audience;
    roundNumber = 1;
    state.round = 1;
    //console.log(newPrompts);
    for(let [key, value] of playersToSockets){
      value.emit('uncheck', '');
    }
    for(let [key, value] of audienceToSockets){
      value.emit('uncheck', '');
    }
    
    newPrompts = [];
    prompts = [];
    state.prompts = [];
    answers = [];
    state.answers = [];
    votes = 0;
    state.votes = 0;
    currentPrompt = null;
    state.currentPrompt = null;
    combosToPrompts = new Map();
    promptsToCombos = new Map();
    socketsToPrompts = new Map();
    socketToPrompts = new Map();
    playerNumberAdjust = new Map();
    audienceNumberAdjust = new Map();
    playerCombos = [];
    promptsSubmitted = 0;
    answersSubmitted = 0;
    emptyPrompts = 0
    state.state = 1;
    //console.log(state);
    for(let [key, value] of playersToSockets){
      value.emit('disconnectUpdate', state);
    }
    for(let [key, value] of audienceToSockets){
      value.emit('disconnectUpdate', state);
    }
    for(let i = 0; i < displaySockets.length; i++){
      displaySockets[i].emit('state',state);
    }
    for(let i = 0; i < state.players.length; i++){
      playerNumberAdjust.set(state.players[i].number, i + 1);
      state.players[i].number = i + 1;
    }
    for(let i = 0; i < state.audience.length; i++){
      audienceNumberAdjust.set(state.audience[i].number, i + 1);
      state.audience[i].number = i + 1;
    }
    //console.log(playerNumberAdjust);
    //console.log(audienceNumberAdjust);
    //console.log(playersToSockets);
    players = state.players;
    audience = state.audience;
    //for(let i = 0; i < players.length; i++){
    for(let [key1, value1] of playersToSockets){
      for(let [key2, value2] of playerNumberAdjust){
        if(key1 == key2){
          playersToSockets.set(value2,value1);
          socketsToPlayers.set(value1,value2);
        }
      }
    }

    for(let [key1, value1] of audienceToSockets){
      for(let [key2, value2] of audienceNumberAdjust){
        if(key1 == key2){
          audienceToSockets.set(value2,value1);
          socketsToAudience.set(value1,value2);
        }
      }
    }

    //for(let [key, value] of audienceToSockets){
      //audienceToSockets.set(audienceNumberAdjust.get(key), value);
      //socketsToAudience.set(value,audienceNumberAdjust.get(key));
    //}


    //console.log(state);
    //console.log(playersToSockets);




        //console.log("number");
        //console.log(players[i].number);
        //console.log("value");
        //console.log(value);
        //if(players[i].number == value){
          //playersToSockets.set(players[i].number, key);
        //}
      //}
    }
    
    
    //for(let i = 0; i < audience.length; i++){
      //for(let [key, value] of socketsToAudience){
        //if(audience[i].number == value){
          //audienceToSockets.set(audience[i].number, key);
        //}
      //}
    //}
    
  

  





//Handle new connection
io.on('connection', socket => { 
  console.log('New connection');
  displaySockets.push(socket);
  for(let i = 0; i < displaySockets.length; i++){
    displaySockets[i].emit('state',state);
  }
  //console.log(displaySockets.length);

  //Handle on chat message received
  socket.on('login', message => {
    if(state.state < 3){
    if(displaySockets.indexOf(socket) > -1){
      displaySockets.splice(displaySockets.indexOf(socket),1);
    }
    handleLogin(message,socket);
    }
    else{
      socket.emit("inGame",'');
    }
  });

  socket.on('register', message => {
    handleRegister(message,socket);
  });

  socket.on('advanceToPrompts', message => {
    if(players.length >= 3){
    handleAdvanceToPrompts();
    }
  });

  socket.on('createPrompt', message => {
    handleCreatePrompt(message,socket);
  });

  socket.on('startAnswers', message => {
    if(promptsSubmitted == players.length + audience.length){
    handleStartAnswers();
    }
  });

  socket.on('submitAnswers', message => {
    handleSubmitAnswers(message);
  });

  socket.on('endAnswers', message => {
    var submitCheck = players.length;
    if(players.length % 2 != 0){
      submitCheck = players.length * 2;
    }
    if(answersSubmitted == submitCheck){
      handleEndAnswers();
    }
  });

  socket.on('sendVotes', message => {
    handleSendVotes(message);
  });

  socket.on('startScores', message => {
    if(state.currentPrompt.player1.votes + state.currentPrompt.player2.votes == state.players.length + state.audience.length - 2){
      handleEndVotes();
    }
  });

  socket.on('nextVote', message => {
    handleNextVote();
  });

  socket.on('startRoundScores',message =>{
    handleStartRoundScores();
  });

  socket.on('nextRound',message =>{
    handleNextRound();
    
  });

  socket.on('scoreUpdate', message => {
    state = message;
  });
  socket.on('gameOver', message => {
    handleGameOver();
  });

  socket.on('promptsAndAnswers', message => {
    promptsAndAnswers.push(message);
    //console.log(promptsAndAnswers);
    var joinedPromptsAndAnswers = [];
    var found = false;
    for(let i = 0; i < promptsAndAnswers.length; i++){
      joinedPromptsAndAnswers.push({prompt: promptsAndAnswers[i].prompt, answers: [promptsAndAnswers[i].answer]})
      for(let y = i+1; y < promptsAndAnswers.length; y++){
        if(promptsAndAnswers[i].prompt.id == promptsAndAnswers[y].prompt.id){
          joinedPromptsAndAnswers.push({prompt: promptsAndAnswers[i].prompt, answers: [promptsAndAnswers[i].answer,promptsAndAnswers[y].answer]});
        } 
    }
  }
  
  joinedPromptsAndAnswers.sort(function(a, b){
    return b.answers.length - a.answers.length;
});

  //console.log(joinedPromptsAndAnswers);

  var newJoined = [];
  var doubles = joinedPromptsAndAnswers.filter(prompt => prompt.answers.length == 2);
  var singles = joinedPromptsAndAnswers.filter(prompt => prompt.answers.length == 1);

  //console.log(doubles);
  //console.log(singles);


  
  var promptTextList = [];
  for(let i = 0; i < doubles.length; i++){
    promptTextList.push(doubles[i].prompt.id);
    }

  for(let i = 0; i < singles.length; i++){
    if(!(promptTextList.includes(singles[i].prompt.id))){
      newJoined.push(singles[i]);
    }
  }

  
  
  joinedPromptsAndAnswers = newJoined.concat(doubles);
  console.log(joinedPromptsAndAnswers);
  for(let i = 0; i < displaySockets.length; i++){
    displaySockets[i].emit('answers', joinedPromptsAndAnswers);
  }

  });



  //Handle disconnection
  socket.on('disconnect', () => {
    if(!(displaySockets.includes(socket))){
      handleDisconnect(socket);
    }
    
  });
});

//Start server
if (module === require.main) {
  startServer();
}

module.exports = server;

function apiFunction(requestData,path) {
  const playerOptions = requestOptions;
  playerOptions.path = path;
  var https = require("https");

  return new Promise((resolve, reject) => {
      const request = https.request(playerOptions, (res) => {
          let data = '';
          res.on('data', (chunk) => {
              data += chunk;
          });

          res.on('close', () => {
            resolve(JSON.parse(data));
          });

          res.on('error', (error) => {
              reject(error);
          });
      });

      request.write(JSON.stringify(requestData));
      request.end()
  });
}

function shuffle(array) {
  let currentIndex = array.length,  randomIndex;

  // While there remain elements to shuffle.
  while (currentIndex != 0) {

    // Pick a remaining element.
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex--;

    // And swap it with the current element.
    [array[currentIndex], array[randomIndex]] = [
      array[randomIndex], array[currentIndex]];
  }

  return array;
}

function getPromptsEven(){
  //console.log("even");
  //console.log(apiPrompts);
  //console.log(newPrompts.length);
  newPrompts = shuffle(newPrompts);
  apiPrompts = shuffle(apiPrompts);
  
  //console.log(newPrompts);
  //console.log(apiPrompts);

  if(apiPrompts.length >= (promptNumber/2) && newPrompts.length >= (promptNumber/2)){
    console.log(1);
    prompts = apiPrompts.slice(0,(promptNumber/2) ).concat(newPrompts.slice(0,(promptNumber/2) ));
    //console.log(prompts);
  }
  if(apiPrompts.length + newPrompts.length < promptNumber){
    //console.log(2);
    prompts = apiPrompts.concat(newPrompts);
    while(prompts.length < promptNumber){
      prompts.push({id:emptyPrompts,text:"Empty prompt"})
      emptyPrompts +=1
    }
    
    //console.log(prompts);
  }
  if((apiPrompts.length + newPrompts.length >= promptNumber) && apiPrompts.length < (promptNumber/2) ){
    console.log(3);
    prompts = prompts.concat(shuffle(apiPrompts));
    for(let i = 0; i < newPrompts.length; i++){
      if(prompts.length == promptNumber){
        break
      }
      prompts.push(newPrompts[i]);
    }
    
    //console.log(prompts);
  }
  if((apiPrompts.length + newPrompts.length >= promptNumber) && newPrompts.length < (promptNumber/2) ){
    console.log(4);
    prompts = prompts.concat(newPrompts);
    //var shuffledapiPrompts = shuffle(apiPrompts);
    //console.log(shuffledapiPrompts);
    //console.log(promptNumber);
    //console.log(prompts);
    for(let i = 0; i < apiPrompts.length; i++){
      if(prompts.length == promptNumber){
        break
      }
      prompts.push(apiPrompts[i]);
      
    }
    
    
    //}
    //console.log(prompts);
  }
}

function getPromptsOdd(){
  //console.log("odd");
  //console.log(apiPrompts);
  //console.log(newPrompts.length);
  newPrompts = shuffle(newPrompts);
  apiPrompts = shuffle(apiPrompts);
  //console.log("new");
  
  //console.log("api");
  //console.log(apiPrompts);

  if(apiPrompts.length >= ((promptNumber+1)/2) && newPrompts.length >= ((promptNumber+1)/2)){
    console.log(1);
    prompts = apiPrompts.slice(0,((promptNumber+1)/2) - 1 ).concat(newPrompts.slice(0,(promptNumber+1)/2 ));
    //console.log(prompts);
    //console.log(newPrompts);
  }
  if(apiPrompts.length + newPrompts.length < promptNumber){
    console.log(2);
    prompts = apiPrompts.concat(newPrompts);
    while(prompts.length < promptNumber){
      prompts.push({id:emptyPrompts,text:"Empty prompt"})
      emptyPrompts +=1
    }
    
    //console.log(prompts);
  }
  if((apiPrompts.length + newPrompts.length >= promptNumber) && apiPrompts.length < ((promptNumber+1)/2) ){
    console.log(3);
    prompts = prompts.shuffle(apiPrompts);
    //var shuffledNewPrompts = shuffle(newPrompts);
    for(let i = 0; i < newPrompts.length; i++){
      if(prompts.length == promptNumber){
        break
      }
      prompts.push(newPrompts[i]);
      
    }
    
    //console.log(prompts);
  }
  if((apiPrompts.length + newPrompts.length >= promptNumber) && newPrompts.length < ((promptNumber+1)/2) ){
    console.log(4);
    prompts = prompts.concat(newPrompts);
    
    //console.log(apiPrompts);
    //var shuffledapiPrompts = shuffle(apiPrompts);
    //console.log(shuffledapiPrompts);
    //console.log(promptNumber);
    //console.log(prompts);
    //console.log(newPrompts);
    for(let i = 0; i < apiPrompts.length; i++){
      if(prompts.length == promptNumber){
        break
      }
      prompts.push(apiPrompts[i]);
      
    }

    //console.log(newPrompts);
     
    
    //}
    //console.log(prompts);
  }
}


function sliceIntoChunks(arr, chunkSize) {
  const res = [];
  for (let i = 0; i < arr.length; i += chunkSize) {
      const chunk = arr.slice(i, i + chunkSize);
      res.push(chunk);
  }
  return res;
}


const requestOptions = {
  method: 'POST',
  host: 'comp3207kp1g20.azurewebsites.net',
  headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json; charset=UTF-8',
      'x-functions-key': 'N6O0KZ6VeTpQXN3sOCvMalOBoM6yo7FW6jP5Xh2osKaoAzFuokqDDg=='
  }
}
